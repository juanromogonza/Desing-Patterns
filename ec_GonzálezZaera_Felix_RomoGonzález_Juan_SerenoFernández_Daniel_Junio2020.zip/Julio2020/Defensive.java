
/**
 * Write a description of class Deffensive here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Defensive extends Character
{

     /**
     * Constructor para objetos de la clase Defensive
     * @param nombre personaje
     * @param puntos energia
     */
    public Defensive(String name, Double energy)
    {
        super(name, energy);
        setOffensive(20.0);
        setDefensive(25.0);
    }
}
