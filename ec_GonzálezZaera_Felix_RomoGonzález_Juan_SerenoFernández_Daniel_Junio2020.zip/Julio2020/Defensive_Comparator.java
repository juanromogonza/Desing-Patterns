import java.util.Comparator;
/**
 * Write a description of class Defensive_up here.
 *
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Defensive_Comparator implements Comparator<Character>
{
     /**
     * comparador de puntos defensivos
     * @param personaje 1
     * @param personaje 2
     * @returns posicion del personaje comparado
     */
   public int compare(Character character1, Character character2){
       if(character1.getDefensive().equals(character2.getDefensive())){
           return character1.getName().compareTo(character2.getName());
        }
        else{
               return character1.getDefensive().compareTo(character2.getDefensive());
        }
            
    }
}
