
/**
 * Write a description of interface ExtraPotions here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */

public class Extra_Potions extends Character
{
    Character character;
    
    /**
     * Constructor de la clase Extra_Potions
     * @param Personaje dueño de la pocion
     */
    public Extra_Potions(Character character){
        super(character.getName(), character.getEnergy(),character.getOffensive(),character.getDefensive(),character.getWand());
        this.character=character;
    }
    
    /**
     * Consultor de personaje de la pocion
     * @return personaje dueño
     */
    public Character getCharacter(){
        return this.character;
    }
}
