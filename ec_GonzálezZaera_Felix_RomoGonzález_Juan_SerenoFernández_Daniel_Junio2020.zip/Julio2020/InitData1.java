//
/**
 * Write a description of class InitData here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class InitData1
{
    //Instacia Hogwarst para poder cargar los datos
    private Hogwarts hogwarts= Hogwarts.getHogwarts();

    /**
     * Constructor para objetos de la clase InitData
     */
    public InitData1()
    {
        initData1();
    }

    private void initData1(){
        hogwarts.addWand(new  Offensive_Hawthorm("Ivy"));
        hogwarts.addWand(new Offensive_Hawthorm("Larch"));
        hogwarts.addWand(new Holly_Defensive("Rowan"));
        hogwarts.addWand(new  Offensive_Hawthorm("Yew"));
        hogwarts.addWand(new Offensive_Hawthorm("Hazel"));
         hogwarts.addWand(new Offensive_Hawthorm("Pine"));
        hogwarts.addWand(new Holly_Defensive("Tamarack"));
        hogwarts.addWand(new Offensive_Hawthorm("Spruce"));
         hogwarts.addWand(new Offensive_Hawthorm("Pear"));
        hogwarts.addWand(new Offensive_Hawthorm("Laruel"));
        
        Defensive_up deffensiveUp= new Defensive_up();
        Offensive_up offensiveUp= new Offensive_up();
        Offensive_down offensiveDown= new Offensive_down();
        
        
        House gryffindor = new House ("Grynffindor", deffensiveUp);
        
        Character harry = new Offensive("Harry Potter", 20.0);
        harry.setWand(new Offensive_Hawthorm("HarryW"));
        harry= new Invigoration_Potion(harry);
        harry= new Felix_Felicis_Potion(harry);
        
        
        Character hermione = new Defensive("Hermione Granger", 20.0);
        hermione.setWand(new Holly_Defensive("HermioneW"));
        hermione= new Invigoration_Potion(hermione);
        
        
        Character ron = new Defensive("Ron Weasley", 20.0);
        ron.setWand(new Offensive_Hawthorm("RonW"));
        ron= new Felix_Felicis_Potion(ron);
        
        Character neville = new Defensive("Neville Longbottom", 20.0);
        neville.setWand(new Offensive_Hawthorm("NevilleW"));
        
        gryffindor.insertCharacter(harry);
        gryffindor.insertCharacter(hermione);
        gryffindor.insertCharacter(ron);
        gryffindor.insertCharacter(neville);
        gryffindor.orderCharacter();
        System.out.println(gryffindor.toString());
        hogwarts.addHouse(gryffindor);
        
        
        House hufflepuff = new House ("Hufflepuff", offensiveUp);
        
        Character cedric = new Defensive("Cedric Diggory", 20.0);
        cedric.setWand(new Offensive_Hawthorm("CedricW"));
        cedric= new Invigoration_Potion(cedric);
        
        Character nymphadora = new Defensive("Nymphadora Tonks", 20.0);
        nymphadora.setWand(new Offensive_Hawthorm("NymphadoraW"));
        
        Character pomona = new Offensive("Pomona Sprout", 20.0);
        pomona.setWand(new Offensive_Hawthorm("PomonaW"));
        pomona= new Felix_Felicis_Potion(pomona);
        
        Character rolf = new Defensive("Rolf Scamander", 20.0);
        rolf.setWand(new Offensive_Hawthorm("RolfW"));
        
        hufflepuff.insertCharacter(cedric);
        hufflepuff.insertCharacter(nymphadora);
        hufflepuff.insertCharacter(pomona);
        hufflepuff.insertCharacter(rolf);
        hufflepuff.orderCharacter();
        hogwarts.addHouse(hufflepuff);
        
        
        House slytherin = new House ("Slytherin", offensiveDown);
        
        Character draco = new Defensive("Draco Malfoy", 20.0);
        draco.setWand(new Holly_Defensive("DracoW"));
        
        Character dolores = new Offensive("Dolores Umbridge", 20.0);
        dolores.setWand(new Holly_Defensive("DoloresW"));
        
        Character pansy = new Offensive("Pansy Parkinson", 20.0);
        pansy.setWand(new Offensive_Hawthorm("PansyW"));
        pansy = new Felix_Felicis_Potion(pansy);
        
        Character albus = new Offensive("Albus Severus Potter", 20.0);
        albus.setWand(new Holly_Defensive("AlbusW"));
        
        slytherin.insertCharacter(draco);
        slytherin.insertCharacter(dolores);
        slytherin.insertCharacter(pansy);
        slytherin.insertCharacter(albus);
        slytherin.orderCharacter();
        hogwarts.addHouse(slytherin);
  
        
        
        
    }
}