//
/**
 * Write a description of class InitData here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class InitData2
{
    //Instacia Hogwarst para poder cargar los datos
    private Hogwarts hogwarts= Hogwarts.getHogwarts();

    /**
     * Constructor para objetos de la clase InitData
     */
    public InitData2()
    {
        initData2();
    }

    private void initData2(){
        
        hogwarts.addWand(new  Offensive_Hawthorm("Ivy"));
        hogwarts.addWand(new Offensive_Hawthorm("Larch"));
        hogwarts.addWand(new Holly_Defensive("Rowan"));
        hogwarts.addWand(new Offensive_Hawthorm("Yew"));
        hogwarts.addWand(new Offensive_Hawthorm("Hazel"));
        hogwarts.addWand(new Offensive_Hawthorm("Pine"));
        hogwarts.addWand(new Holly_Defensive("Tamarack"));
        hogwarts.addWand(new Offensive_Hawthorm("Spruce"));
        hogwarts.addWand(new Offensive_Hawthorm("Pear"));
        hogwarts.addWand(new Offensive_Hawthorm("Laurel"));
        hogwarts.addWand(new Holly_Defensive("Cypress"));
        hogwarts.addWand(new Holly_Defensive("Ebony"));
        hogwarts.addWand(new Offensive_Hawthorm("Reed"));
        hogwarts.addWand(new Holly_Defensive("Aspen"));
        hogwarts.addWand(new Offensive_Hawthorm("Walnut"));
        
        
        Defensive_up deffensiveUp= new Defensive_up();
        Offensive_up offensiveUp= new Offensive_up();
        Offensive_down offensiveDown= new Offensive_down();
        //grifindor
         
        
        
        House gryffindor = new House ("Grynffindor", deffensiveUp);
        
        Character harry = new Offensive("Harry Potter",20.0);
        harry.setWand(new Holly_Defensive("HarryW"));
         harry= new Invigoration_Potion(harry);
         harry= new Felix_Felicis_Potion(harry);
        
        
        Character hermione = new Offensive("Hermione Granger",20.0);
        hermione.setWand(new Holly_Defensive("HermioneW"));
         hermione= new Invigoration_Potion(hermione);
         hermione= new Felix_Felicis_Potion(hermione);
        
        Character ron = new Offensive("Ron Weasley",20.0);
        ron.setWand(new Holly_Defensive("RonW"));
        ron= new Felix_Felicis_Potion(ron);
        
       
        gryffindor.insertCharacter(harry);
        gryffindor.insertCharacter(hermione);
        gryffindor.insertCharacter(ron);
        gryffindor.orderCharacter();
        hogwarts.addHouse(gryffindor);
        
        
        
        //Hufflepuff's characters
        //------------------------------
        
        
        House hufflepuff = new House ("Hufflepuff", offensiveUp);
        
        Character cedric = new Defensive("Cedric Diggory",20.0);
        cedric.setWand(new Offensive_Hawthorm("CedricW"));
         cedric= new Invigoration_Potion(cedric);
        
        Character nymphadora = new Defensive("Nymphadora Tonks",20.0);
        nymphadora.setWand(new Offensive_Hawthorm("NymphadoraW"));
        
        Character pomona = new Defensive("Pomona Sprout",20.0);
        pomona.setWand(new Offensive_Hawthorm("PomonaW"));
         pomona= new Felix_Felicis_Potion(pomona);
        
        Character rolf = new Defensive("Rolf Scamander",20.0);
        rolf.setWand(new Offensive_Hawthorm("RolfW"));
        
        Character silvanus = new Defensive("Silvanus kettlebrun",20.0);
        silvanus.setWand(new Offensive_Hawthorm("SilvanusW"));
        silvanus= new Felix_Felicis_Potion(silvanus);
        
        Character susan = new Defensive("Susan Bones",20.0);
        susan.setWand(new Offensive_Hawthorm("SusanW"));
        
        
        Character newton= new Defensive("Newton Scamander",20.0);
        newton.setWand(new Offensive_Hawthorm("NewtonW"));
        
        
        Character hannah= new Defensive("Hannah Abbott",20.0);
        hannah.setWand(new Offensive_Hawthorm("HannahW"));
        hannah= new Felix_Felicis_Potion(hannah);
        
        hufflepuff.insertCharacter(cedric);
        hufflepuff.insertCharacter(nymphadora);
        hufflepuff.insertCharacter(pomona);
        hufflepuff.insertCharacter(rolf);
        hufflepuff.insertCharacter(silvanus);
        hufflepuff.insertCharacter(susan);
        hufflepuff.insertCharacter(newton);
        hufflepuff.insertCharacter(hannah);        
        hufflepuff.orderCharacter();
        hogwarts.addHouse(hufflepuff);
        
        
        House slytherin = new House ("Slytherin", offensiveDown);
        
        Character draco = new Defensive("Draco Malfoy",20.0);
        draco.setWand(new Holly_Defensive("DracoW"));
        draco= new Felix_Felicis_Potion(draco);
        
        slytherin.insertCharacter(draco);
        slytherin.orderCharacter();
        hogwarts.addHouse(slytherin);
        
    }
}