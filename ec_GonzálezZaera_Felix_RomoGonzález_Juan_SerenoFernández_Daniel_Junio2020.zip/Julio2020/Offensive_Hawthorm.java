
/**
 * Write a description of class OffensiveHawthorm here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Offensive_Hawthorm extends Wand
{

    /**
     * Constructor de la clase Offensive_Hawthorn
     * @param nombre varita
     */
    public Offensive_Hawthorm (String name){
        super(name);
    }

    /**
     * Metodo toString de la calse Offensive_Hawthorn
     * @return String con los datos de la clase
     */
    public String toString(){
        StringBuilder builder= new StringBuilder();
        builder.append(super.toString());
        builder.append("(Offensive_Hawthorm)");
        return builder.toString();
    }
    
    /**
     * Implementa el metodo de la superclase
     * @return puntos ataque
     * @param personaje
     */
    public Double offensiveUses (Character character){
        return(0.6 * character.getEnergy() + 1.4 * character.getOffensive());
    }

    /**
     * Implementa el metodo de la superclase
     * @return puntos defensa 
     * @param personaje
     */
    public Double defensiveUses (Character character){
        return(0.8 * character.getEnergy() + 0.2 * character.getDefensive());
    }
}
