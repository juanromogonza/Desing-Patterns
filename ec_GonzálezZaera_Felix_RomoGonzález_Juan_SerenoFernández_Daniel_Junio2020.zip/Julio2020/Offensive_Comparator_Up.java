import java.util.Comparator;
/**
 * Write a description of class Offensive_up here.
 *
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Offensive_Comparator_Up implements Comparator<Character>
{
     /**
     * comparador de puntos ofensivos
     * @param personaje 1
     * @param personaje 2
     * @returns posicion del personaje comparado
     */
   public int compare(Character character1, Character character2){
       if(character1.getOffensive().equals(character2.getOffensive())){
           return character1.getName().compareTo(character2.getName());
        }
        else{
               return character1.getOffensive().compareTo(character2.getOffensive());
        }
            
    }
}
