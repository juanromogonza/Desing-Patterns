
/**
 * Write a description of class Offensive here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Offensive extends Character 
{
     /**
     * Constructor para objetos de la clase Offensive
     * @param nombre personaje
     * @param puntos energia
     */
    public Offensive(String name, Double energy)
    {
        super(name, energy);
        setOffensive(25.0);
        setDefensive(20.0);
    }
}
