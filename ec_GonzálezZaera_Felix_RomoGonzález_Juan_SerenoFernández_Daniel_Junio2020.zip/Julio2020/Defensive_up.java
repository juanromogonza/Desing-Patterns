import java.util.ArrayList;
import java.util.Collections;
/**
 * Write a description of class Defensive_down here.
 *
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Defensive_up implements Order
{
     /**
     * Interfaz para la ordenacion por puntos defensivos orden ascendiente
     * @param lista de personajes
     */
    public void order(ArrayList<Character> character){
        Collections.sort(character, new Defensive_Comparator());
    }
}
