import java.util.Comparator;
/**
 * Write a description of class Offensive_Comparator_Down here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Offensive_Comparator_Down implements Comparator<Character>
{
    /**
     * comparador de puntos ofensivos
     * @param personaje 1
     * @param personaje 2
     * @returns posicion del personaje comparado
     */
   public int compare(Character character1, Character character2){
       if(character2.getOffensive().equals(character1.getOffensive())){
           return (character2.getName().compareTo(character1.getName()));
        }
        else{
               return character2.getOffensive().compareTo(character1.getOffensive());
        }
            
    }
}
