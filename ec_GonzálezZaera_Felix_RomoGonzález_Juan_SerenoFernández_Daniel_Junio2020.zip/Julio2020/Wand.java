
/**
 * Write a description of class Wand here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public abstract class Wand implements Comparable <Wand>
{
    //Wand's name
    private String name;
    
    /**
     * Constructor para objetos de la clase Wand
     * @param nombre varita
     */
    public Wand (String name){
        this.name= name;
    }
    
     /**
      * Consultor de nombre de la varita
     * @return nombre varita
     */
    public String getName(){
        return name;
    }
    
    /**
     * Metodo toString de la clase Wand
     * @return String con los datos de la clase
     */
    public String toString(){
        StringBuilder builder= new StringBuilder();
        builder.append("wand: "  + getName());
        return builder.toString();
    }
    
    /**
     * Comparador de varitas
     * @return el entero que indica que varita es mayor
     * @param varita a comparar
     */
    public int compareTo (Wand wand){
        return getName().compareTo(wand.getName());
    }
    
    /**
     * Metodo abstracto que devuelve los puntos despues de
     * los efectos de la varita sobre los puntos ofensivos
     * @return puntos ataque
     * @param personaje 
     */
    abstract Double offensiveUses (Character character);

    /**
     * Metodo abstracto que devuelve los puntos despues de
     * los efectos de la varita sobre los puntos defensivos
     * @return los puntos de resistencia 
     * @return puntos defensa
     * @param personaje 
     */
    abstract Double defensiveUses (Character character);
}
