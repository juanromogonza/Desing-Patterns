
/**
 * Write a description of class Demo here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Demo
{
    public static void main (String[]args){
        int turns=10;
        InitData1 initData1= new InitData1();
        //InitData2 initData2= new InitData2();
        Hogwarts hogwarts= Hogwarts.getHogwarts();
        hogwarts.simulation(turns);
    }
}
