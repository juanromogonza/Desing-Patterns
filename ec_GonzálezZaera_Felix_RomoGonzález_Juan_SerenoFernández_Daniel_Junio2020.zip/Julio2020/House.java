import java.util.ArrayList;
import java.util.Collections;
/**
 * Write a description of class House here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class House 
{
    // Lista donde se guardan los Character
    private ArrayList<Character>character;
    // Nombre de House
    private String name;
    // Atributo usado para la ordenacion de Character
    private Order order;
    /**
     * Constructor para objetos de la clase House
     * @param nombre del personaje
     * @param ordenacion de personajes 
     */
    public House(String name, Order order)
    {
        character= new ArrayList<Character>();
        this.name= name;
        this.order= order;
    }

    /**
     * Consultor del nombre de la casa
     * @return nombre casa
     */
    public String getName(){
        return name;
    }

    /**
     * Modifica el nombre de House
     * @param nombre casa
     */
    public void setName(String name){
        this.name= name;
    }

    /**
     * Modifica el nombre del atributo de ordenacion
     * @param ordenacion de la casa
     */
    public void setOrder(Order order){
        this.order= order;
    }

    /**
     * Ordena la lista character
     */
    public void orderCharacter(){
        System.out.println(character);
        System.out.println(this.name);
        order.order(character);
    }

    /**
     * Inserta un Character en la lista character AL FINAL
     * @param personaje a insertar
     */
    public void insertCharacter (Character character){
        this.character.add(character);
        character.setHouse(name);
    }

    /**
     * Consultor de personajes de la casa
     * @return lista de Character de House
     */
    public ArrayList<Character> getCharacter(){
        return character;
    }

    /**
     * Envia el primer Character de la lista character
     * @return personaje enviado
     */
    public Character sendCharacter(){
        Character aux=character.get(0);
        character.remove(0);
        return aux;
    }

    /**
     * Contador de personajes restantes de la casa
     * @return numero personajes
     */
    public int countCharacter(){
        int cont=0;
        for(Character x: character) {
            cont++;
        }
        return cont;
    }

    /**
     * Contador de la suma de puntos de energia de los personajes de la casa
     * @return puntos energia sumados
     */
    public Double countEnergy(){
        Double cont=0.0;
        for(Character x: character){
            cont=cont+x.getEnergy();
        }
        return cont;
    }

    /**
     * Contador de la suma de puntos defensivos
     * y ofensivos de los personajes de la casa
     * @return puntos defensivos y ofensivos sumados
     */
    public Double countAttDef(){
        Double cont=0.0;
        for(Character x: character){
            cont=cont + x.getOffensive()+x.getDefensive();
        }
        return cont;
    }

    /**
     * Metodo toString de la clase House
     * @return string con los datos de la clase
     */
    public String toString(){
        StringBuilder builder= new StringBuilder();
        builder.append("house:<" + name + ">");
        builder.append('\n');
        for(Character character: character){
            builder.append(character.toString());
            builder.append('\n');
        }
        return builder.toString();
    }
}





