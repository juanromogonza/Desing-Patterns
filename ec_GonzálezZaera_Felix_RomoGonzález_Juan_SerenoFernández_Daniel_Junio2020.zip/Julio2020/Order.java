import java.util.ArrayList;
/**
 * Write a description of class Order here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public interface Order
{
    /**
     * Interfaz para todas las opciones diferentes de ordenacion
     * @param lista de personajes
     */
    public void order (ArrayList<Character> character);
}
