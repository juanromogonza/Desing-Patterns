import java.util.ArrayList;
import java.util.Collections;
/**
 * Write a description of class Energy_down here.
 *
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Energy_down implements Order
{
     /**
     * Interfaz para la ordenacion por puntos energia orden descendiente
     * @param lista de personajes
     */
    public void order(ArrayList<Character> character){
        Collections.sort(character, Collections.reverseOrder(new Energy_Comparator()));
    }
}
