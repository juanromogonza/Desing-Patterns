import java.util.ArrayList;
/**
 * Write a description of class Character here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public abstract class  Character 
{
    //Character`s name
    private String name;
    //Character`s energy
    private Double energy;
    //Character`s offensive points
    private Double offensive;
    //Character`s defensive points
    private Double defensive;
    //Character`s wand
    private Wand wand;
    // Character's house
    private String house;


    /**
     * Constructor para objetos de la clase Character
     * @param nombre personaje
     * @param puntos energia
     */
    public  Character(String name, Double energy)
    {
        this.name= name;
        this.energy= energy;
        wand= null;
    }
    
    /**
     * Constructor para objetos de la clase Character
     * @param nombre personaje
     * @param puntos energia
     * @param puntos ofensivos
     * @param puntos defensivos
     * @param varita del personaje
     */
    public Character(String name,Double energy,Double offensive,Double defensive,Wand wand)
    {
        this.name=name;
        this.energy=energy;
        this.offensive=offensive;
        this.defensive=defensive;
        this.wand=wand;
    }
    
    /**
     * Consultor de nombre de personaje
     * @return el nombre de Character
     */
    public String getName(){
        return name;
    }

    /**
     * Consultor de la casa del personaje
     * @return la casa de Character
     */
    public String getHouse(){
        return house;
    }

    /**
     * Consultor de energia del personaje
     * @return la energia de Character
     */
    public Double getEnergy(){
        return energy;
    }

    /**
     * Consultor de puntos ofensivos del personaje
     * @return los puntos ofensivos de Character
     */
    public Double getOffensive(){
        return offensive;
    }

    /**
     * Consultor de puntos defensivos del personaje
     * @return los puntos defensivos de Character
     */
    public Double getDefensive(){
        return defensive;
    }

    /**
     * Consultor de varita de personaje
     * @return la wand de Character
     */
    public Wand getWand(){
        return wand;
    }

    /**
     * Modifica el nombre de Character
     * @param nombre personaje
     */
    public void setName(String name){
        this.name= name;
    }

    /**
     * Modifica la casa de Character
     * @param casa del personaje
     */
    public void setHouse(String house){
        this.house= house;
    }

    /**
     * Modifica la energia de Character
     * @param puntos energia
     */
    public void setEnergy(Double energy){
        this.energy= energy;
    }

    /**
     * Modifica los puntos ofensivos de Character
     * @param puntos ofensivos
     */
    public void setOffensive(Double offensive){
        this.offensive= offensive;
    }

    /**
     * Modifica los puntos defensivos de Character
     * @param puntos defensivos
     */
    public void setDefensive(Double defensive){
        this.defensive= defensive;
    }

    /**
     * Modifica la wand de Character
     * @param varitad del personaje
     */
    public void setWand(Wand wand){
        this.wand= wand;
    }

    /**
     * El Character combate contra un oponente dado
     * @param personaje oponente
     */
    public void fight(Character opponent){
        Double offensive= getOffensive();
        if(getWand() != null){
            offensive= getWand().offensiveUses(this);
        }
        Double resistance= opponent.resistance();
        if(offensive > resistance){
            Double energy= opponent.getEnergy() - (offensive - resistance);
            opponent.setEnergy(energy);
        }
    }

    /**
     * Calcula los puntos defensivos del personaje con la varita
     * @return la resistencia de Character cuando usa una wand defensive
     */
    public Double resistance(){
        if(wand != null){
            return getWand().defensiveUses(this);
        }
        return getDefensive();
    }

    /**
     * Calcula los puntos ofensivos del personaje con la varita
     * @return el poder de Character cuando usa una wand offensive
     */
    public Double attack(){
        
        if(getWand() != null){
            return getWand().offensiveUses(this);
        }
        return getOffensive();
    }
    
    /**
     * Metodo toString de la clase personaje
     * @return string de los datos de la clase
     */
    public String toString(){
        double newEnergy = ((double)Math.round(getEnergy() * 100d) / 100d);
        StringBuilder builder= new StringBuilder();
        builder.append("Character:<" + getName()+">");
        builder.append(" <e: " + newEnergy+">");
        builder.append(" <o: " + getOffensive()+">");
        builder.append(" <d: " + getDefensive()+">");
        builder.append(" <"+getWand().toString()+">");
        return builder.toString();
    }
}