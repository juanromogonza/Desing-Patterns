import java.util.Comparator;
/**
 * Write a description of class Energy_up here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Energy_Comparator implements Comparator<Character>
{
     /**
     * comparador de puntos de energia
     * @param personaje 1
     * @param personaje 2
     * @returns posicion del personaje comparado
     */
    public int compare(Character character1, Character character2){
       if(character1.getEnergy().equals(character2.getEnergy())){
           return character1.getName().compareTo(character2.getName());
        }
        else{
               return character1.getEnergy().compareTo(character2.getEnergy());
        }
            
    }
}
