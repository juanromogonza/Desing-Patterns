


import java.util.HashMap;
import java.util.TreeSet;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
/**
 * Write a description of class Hogwarts here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Hogwarts
{
    //HashMap de todas House que hay en curso
    private HashMap<String,House> houses;
    //Lista que guarda los Characters que se han quedado sin energia
    private ArrayList<Character> dungeon;
    //Lista que guarda los Characters que se baten en duelo
    private ArrayList<Character> duel;
    // atributo de ordenacion
    private Order orderEnergy;
    // TreeMap para Wand
    private TreeSet<Wand> wands; 
    //Instancia de Hogwarts
    public static Hogwarts hogwarts;

    private BufferedWriter bw;

    /**
     * Constructor para objetos de la clase Hogwarts
     */
    private Hogwarts(){
        houses= new HashMap<String,House> ();
        dungeon= new ArrayList<Character> ();
        duel= new ArrayList<Character> ();
        orderEnergy = new Energy_up();
        wands= new TreeSet<Wand>();
        try {        
            bw= new BufferedWriter(new FileWriter("registro.log"));
        } catch (IOException e) {
        }
    }

    /**
     * Uso del Singleton  para evitar creacion de más de un main
     */
    public static Hogwarts getHogwarts(){
        if(hogwarts==null){
            hogwarts= new Hogwarts();
        }
        return hogwarts;
    }

    /**
     * Añade a Hogwarst una House nueva
     * @param casa que se añade
     */
    public void addHouse(House house){
        houses.put(house.getName(), house);
    }

    /**
     * Añade una Wand nueva a Hogwarst
     * @param varita que se añade
     */
    public void addWand(Wand wand){
        wands.add(wand);
    }

    /**
     * Realizacion del duelo entre todas las Houses
     * @param numero de turnos que van a realizarse
     */
    public void Duel(int turns){
        int cont=0;
        int i, j, k;
        Character fighter1, fighter2;
        House winnerHouse;
        while(cont < turns && houseDuel()){
            try {
                bw.write("Turn: <" + cont + ">");
                bw.newLine();
                bw.newLine();
                bw.write("Character who are going to duel:");
                bw.newLine();
                bw.write("--------------------------------");
                bw.newLine();
            } catch (IOException e) {
            }
            sendCharacterToDuel();
            orderEnergy.order(duel);
            j=0;
            while(j< duel.size()){
                try {
                    bw.write(duel.get(j).toString());
                    bw.newLine();
                } catch (IOException e) {
                }
                j++;
            }
            try{

                bw.newLine();
                bw.newLine();
                bw.write("duels:");
                bw.newLine();
                bw.write("-----");
                bw.newLine();  
            }catch(IOException e){
            }
            j=0;
            while(j< duel.size()){
                fighter1= duel.get(j);
                if(fighter1.getEnergy()> 0){
                    k=0;
                    while(k< duel.size()){
                        fighter2= duel.get(k);
                        double newEnergy = ((double)Math.round(fighter2.getEnergy() * 100d) / 100d);
                        double newAttack = ((double)Math.round(fighter1.attack() * 100d) / 100d);
                        double newResistance = ((double)Math.round(fighter2.resistance() * 100d) / 100d);
                        if(newResistance<=0){
                            newResistance=0;
                        }
                        if(fighter1.getName()!= fighter2.getName() && fighter2.getEnergy()> 0){
                            try {

                                bw.write("<"+fighter1.getName() + "> is dueling against <" + fighter2.getName() + ">");
                                bw.newLine();
                                bw.write("Attack points of <" + fighter1.getName() + "> are: <" + newAttack + ">");
                                bw.newLine();

                                bw.write("Resistance points of <" + fighter2.getName() + "> are: <" + newResistance + ">");
                                bw.newLine();
                            } catch (IOException e) {
                            }
                            fighter1.fight(fighter2);
                            try {
                                newEnergy = ((double)Math.round(fighter2.getEnergy() * 100d) / 100d);
                                bw.write("The remaining energy of <" + fighter2.getName() + "> after the duel are: <" + newEnergy + ">");
                                bw.newLine();
                                bw.newLine();
                            } catch (IOException e) {
                            }
                        }
                        k++;
                    }
                }
                j++;
            }                                 
            cont= cont + 1;
            try {
                bw.write("Duel results:");
                bw.newLine();
                bw.write("------------");
                bw.newLine(); 
            } catch (IOException e) {
            }
            moveAfterDuel();
            duel.removeAll(duel);
        }       
        displayResults();

    }

    /**
     * Obtencion de los personajes de cada casa para el duelo
     */
    void sendCharacterToDuel(){
        for(House house: houses.values()){
            if(house.getCharacter().size()>0){
                duel.add(house.sendCharacter());
            }
        }
    }

    /**
     * Salida por pantalla del resultado final
     */
    private void displayResults(){
        try {
            bw.newLine();
            bw.write("End of the simulation:");
            bw.newLine();
            bw.write("----------------------");
            bw.newLine();
            bw.write("Houses:");
            bw.newLine();
            bw.write("-------");
            bw.newLine();
            for(House house: houses.values()){
                bw.write(house.toString());
                bw.newLine();
            }
            bw.write("New wands:");
            bw.newLine();
            bw.write("----------");
            bw.newLine();
            for(Wand wand: wands){
                bw.write(wand.toString());
                bw.newLine();
            }
            bw.write("Dungeons characters:");
            bw.newLine();
            bw.write("-------------------");
            bw.newLine();
            bw.newLine();
            for(Character character: dungeon){
                bw.write(character.toString());
                bw.newLine();
            }
            bw.newLine();
            bw.write("The winner house is:");
            bw.newLine();
            bw.write("-------------------");
            bw.newLine();
            bw.write(winHouse().toString());
        } catch (IOException e) {
        }
    }

    /**
     * Colocacio de los characters despues de cada duelo
     */
    private void moveAfterDuel(){
        Wand first;
        for(Character character: duel){
            if(character.getEnergy()> 0){
                try {
                    bw.write(character.toString());
                    bw.write("Returns to the house");
                    bw.newLine();
                } catch (IOException e) {
                }
                if(wands.size()>0){
                    first= wands.first();
                    character.setWand(first);
                    try {
                        bw.write("New wand assigned: " + first.toString());
                        bw.newLine();
                    } catch (IOException e) {
                    }
                    wands.remove(first);
                }
                houses.get(character.getHouse()).insertCharacter(character);
            }
            else{
                try {
                    bw.write("Goes to the dungeon");
                    bw.newLine();
                    bw.write(character.toString());
                    bw.newLine();
                    bw.newLine();
                } catch (IOException e) {
                }
                character.setEnergy(0.0);
                dungeon.add(character);
            }
        }
    }

    /**
     * Crea un Arralist<String> key que guarda las claves del HashMap House para 
     * compararlas entre ellas
     * @returns casa ganadora
     */
    private House winHouse(){
        String name=" "; 
        House solution=new House(name,orderEnergy);
        ArrayList<String> key=new ArrayList();
        if(!houseDuel()){
            for(House house: houses.values()){
                if(house.getCharacter().size()>0){
                    solution=house;
                }
            }
        }else{
            for(House house: houses.values()){
                key.add(house.getName());                
            }   
            solution=chooseWinnerHouse(key);
        }
        return solution;
    }

    /**
     * Realiza la comparacion entre las Houses para saber la ganadora
     * @returns winner house,la casa ganadora
     * @param array de keys del hashmap de casas
     */
    private House chooseWinnerHouse(ArrayList<String> key){
        House betterHouse=houses.get(key.get(0)) ,actualHouse;
        int cont=0;
        for(String aux: key){
            if(houses.containsKey(aux)){
                if(cont==0){
                    betterHouse= houses.get(aux);
                    cont++;
                }else{
                    actualHouse= houses.get(aux);
                    if(actualHouse.countCharacter()>betterHouse.countCharacter()){
                        betterHouse=actualHouse;
                    }else{
                        if(actualHouse.countCharacter()==betterHouse.countCharacter()){
                            if(actualHouse.countEnergy()>betterHouse.countEnergy()){
                                betterHouse=actualHouse;
                            } else{
                                if(actualHouse.countEnergy()==betterHouse.countEnergy()){
                                    if(actualHouse.countAttDef()>betterHouse.countAttDef()){
                                        betterHouse=actualHouse;
                                    }       
                                }
                            }       
                        }
                    }
                }                
            }
        }
        return betterHouse;
    }

    /**
     * Realiza la comparacion entre los Characters restantes para saber
     * si son de la misma casa y asi acabar la partida
     * @returns booleano indicando si solo quedan personajes de una casa
     */
    private boolean houseDuel(){
        boolean flag1=false,flag2=false;
        House house2;        
        for(House house: houses.values()){                                
            if(house.getCharacter().size()>0 && !flag1){
                flag1=true;
            }else{
                if(house.getCharacter().size()>0){
                    flag2=true;
                }
            }                
        }        
        return flag2;
    }
    
    /**
     * Indica la simulacion y guarda los primeros datos en el fichero log
     * @param turnos de la simulacion
     */
    public void simulation(int turns){
        try {
            bw.write("Houses:");
            bw.newLine();
            bw.write("-------");
            bw.newLine();
            for(House house: houses.values()){
                bw.write(house.toString());
                bw.newLine();
                bw.newLine();
            }
            bw.write("New wands:");
            bw.newLine();
            bw.write("-------");
            bw.newLine();
            for(Wand wand: wands){
                bw.write(wand.toString());
                bw.newLine();
            }
            bw.newLine();
            Duel(turns);
            bw.close();
        } catch (IOException e) {
        }
    }

}
