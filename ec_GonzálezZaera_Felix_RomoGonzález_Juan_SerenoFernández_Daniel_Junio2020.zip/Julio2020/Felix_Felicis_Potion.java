
/**
 * Write a description of class FelixFelicisPotion here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Felix_Felicis_Potion extends Extra_Potions
{
    /**
     * Constructor de la clase Felix_Felicis_Potion
     * @param personaje dueño de la pocion
     */
     public Felix_Felicis_Potion(Character character){ 
        super(character);
       
    }
    
    /**
     * Consultor de puntos ofensivos del personaje despues de usar la pocion
     * @return puntos ofensivos
     */
    @Override
    public Double getOffensive(){
        return getCharacter().getOffensive()*1.3;
    }
    
    
}
