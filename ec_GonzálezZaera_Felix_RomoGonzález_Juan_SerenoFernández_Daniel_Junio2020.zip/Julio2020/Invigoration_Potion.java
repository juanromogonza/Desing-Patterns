
/**
 * Write a description of class InvigorationPotion here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Invigoration_Potion extends Extra_Potions
{
    /**
     * Constructor de la clase Invigoration_Potion
     * @param personaje dueño de la pocion
     */
    public Invigoration_Potion(Character character){      
        super(character);
    } 
    
    /**
     * Consultor de puntos defensivos del personaje despues de usar la pocion
     * @return puntos defensivos
     */
    @Override
    public Double getDefensive(){
        return getCharacter().getDefensive()*1.4;
    }
    
    
}
