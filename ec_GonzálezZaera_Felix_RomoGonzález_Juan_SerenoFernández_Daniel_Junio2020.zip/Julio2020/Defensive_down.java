import java.util.ArrayList;
import java.util.Collections;
/**
 * Write a description of class Defensive_down here.
 *
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Defensive_down implements Order
{
    /**
     * Interfaz para la ordenacion por puntos defensivos orden descendiente
     * @param lista de personajes
     */
    public void order(ArrayList<Character> character){
        Collections.sort(character, Collections.reverseOrder(new Defensive_Comparator()));
    }
}
