
/**
 * Write a description of class HollyDefensive here.
 * 
 * @author Daniel Sereno, Juan Romo y Félix Gónzalez 
 * @version 14-03-2020
 */
public class Holly_Defensive extends Wand
{
    /**
     * Constructor para objetos de la clase HollyDefensive
     * @param nombre varita
     */
    public Holly_Defensive (String name){
        super(name);
    }
    
    /**
     * Metodo to string de la clase Holly_Defensive
     * @return String con los datos de la clase
     */
    public String toString(){
        StringBuilder builder= new StringBuilder();
        builder.append(super.toString());
        builder.append("(Holly_Defensive)");
        return builder.toString();
    }
    
    /**
     * Implementa el metodo de la superclase
     * @return puntos ataque
     * @param personaje
     */
    public Double offensiveUses (Character character){
        return(0.7 * character.getEnergy() + 0.3 * character.getOffensive());
    }
    
    /**
     * Implementa el metodo de la superclase
     * @return puntos defensa 
     * @param personaje
     */
    public Double defensiveUses (Character character){
        return(0.9 * character.getEnergy() + 1.1 * character.getDefensive());
    }
}
